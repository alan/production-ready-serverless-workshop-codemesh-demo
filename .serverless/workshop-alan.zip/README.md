# production-ready-serverless-workshop-codemesh-demo

Demo project for the Production-Ready Serverless workshop at CodeMesh
